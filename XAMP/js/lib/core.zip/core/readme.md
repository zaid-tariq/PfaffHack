# Event Broker Connector (pm-core)

You can use this module to connect to the event broker. In the `index.js` file you find a minimal usage example.

## Dependencies

- node
- npm
- run `npm install`

## How to use

Require the connector in your service as shown in `index.js`.
Supports subscribe, unsubscribe, publish and request.
